# AI POS — Граница: Project Stage Engine и project_analyzer

**Статус:** архитектурное описание (без реализации)  
**Дата:** 2026-07-26  
**Связанные документы:** `PROJECT_STAGE_ENGINE.md`, Intake & Discovery, Project Health  

**Важно о коде:** текущий / будущий `project_analyzer.py` **не удалять** — это полезный компонент контура развития.  
На момент фиксации этого документа файла в корне репозитория может ещё не быть; правило сохранения действует, как только компонент появляется или подключается.

---

## 1. Зачем разделение

Два разных вопроса нельзя смешивать в одном выводе:

| Вопрос | Отвечает | Характер |
|---|---|---|
| На каком этапе проект и что из этого следует логически? | **Project Stage Engine** | Детерминированный, на evidence |
| Что ещё важно знать: риски, сводка, мягкие рекомендации? | **project_analyzer** | Аналитический, вероятностный / эвристический |

Если analyzer сам «выбирает стадию», появляется вторая истина, ИИ может подтянуть удобный этап, а UI и Health начинают спорить друг с другом.

---

## 2. Роли компонентов

### 2.1. `project_analyzer.py` (контур развития)

**Делает:**
- анализирует доступное состояние проекта (артефакты, заметки, git/GitHub-сигналы, workflow);
- формирует **сводку** для человека;
- перечисляет **риски** и мягкие наблюдения;
- предлагает **аналитический** следующий шаг / фокус внимания;
- объясняет пользователю уже известную стадию простым языком.

**Не делает:**
- не блокирует действия (не Action Gate, не Review lock);
- не является источником истины для стадии;
- не записывает и не переопределяет `project_stage.json`;
- не назначает `CONFIRMED` стадию (и вообще не выбирает `stage` самостоятельно).

### 2.2. Project Stage Engine (отдельный компонент)

**Делает:**
- работает строго по `PROJECT_STAGE_ENGINE.md`;
- собирает подтверждённые evidence (system-confirmed / user-confirmed; AI-inferred только как слабый сигнал);
- возвращает: `stage`, `confidence_state`, `blockers`, `evidence`, `next_step` (логический, от стадии);
- пишет результат в `project_stage.json` (+ Stage History по правилам Engine).

**Не делает:**
- не подменяет Project Health;
- не заменяет analyzer-сводку;
- не позволяет исполняющему ИИ единолично выставить `confidence_state = CONFIRMED`.

---

## 3. Разделение артефактов результата

| Файл | Содержание | Источник истины? |
|---|---|---|
| **`project_stage.json`** | Фактическая (вычисленная Engine) стадия, confidence, evidence, blockers, next_step от стадии | **Да — для стадии** |
| **`project_analysis.json`** | Вероятностная / эвристическая сводка, риски, наблюдения, мягкие рекомендации analyzer | **Нет для стадии**; аналитический слой |

Рекомендуемое размещение (если проект уже использует `.ai-pos/`):

```text
.ai-pos/
  project_stage.json       ← Stage Engine
  project_analysis.json    ← project_analyzer
  project_state.json       ← workflow / user state (как ранее)
```

Analyzer **читает** `project_stage.json` и может цитировать его поля в сводке.  
Analyzer **не пишет** стадию обратно в `project_stage.json`.

---

## 4. Минимальная схема взаимодействия

```text
Fact sources (Intake, Discovery, Artifacts, Workflow,
Review, Delivery, optional GitHub evidence)
        │
        ▼
Project Stage Engine  (детерминированный)
        │
        │  пишет / обновляет
        ▼
project_stage.json
  (stage, confidence_state, evidence, blockers, next_step)
        │
        │  только чтение стадии
        ├────────────────────────────┐
        ▼                            ▼
project_analyzer.py              UI / Health / Gate
  читает stage.json              используют stage
  + другие факты                 как факт этапа
  пишет analysis.json
        │
        ▼
project_analysis.json
  (summary, risks, soft_next_focus, stage_explanation)
```

### Порядок вызова (минимальный контракт)

1. **Сначала** Stage Engine (или берётся свежий `project_stage.json`, если TTL не истёк).  
2. **Затем** `project_analyzer.py`:  
   - вход: путь проекта, `project_stage.json`, опционально snapshot/state;  
   - выход: `project_analysis.json`.  
3. UI показывает:  
   - стадию и логический next_step — из `project_stage.json`;  
   - сводку и риски — из `project_analysis.json`;  
   - analyzer может повторить stage_label и «почему» **как объяснение**, не как собственный выбор.

### Если стадии ещё нет

```text
project_stage.json отсутствует или stale
  → Analyzer не выдумывает stage
  → в analysis: stage_ref = null | "pending_engine"
  → summary: «Стадия ещё не определена системой — сначала обновите этап»
```

Запрещено: `inferred_stage` в analysis как замена Engine.  
Допустимо: `observations[]` без поля, претендующего на официальную стадию.

---

## 5. Что лежит в каждом JSON (минимально)

### `project_stage.json` (фрагмент контракта Engine)

```json
{
  "schema": "ai-pos.project_stage/v1",
  "stage": "REVIEW",
  "stage_label": "Проверка",
  "confidence_state": "CONFIRMED",
  "evidence": [],
  "blockers": [],
  "next_step": { "text": "…", "action_hint": "open_review" },
  "detected_at": "2026-07-26T00:00:00.000Z",
  "engine": "project_stage_engine"
}
```

### `project_analysis.json` (фрагмент контракта Analyzer)

```json
{
  "schema": "ai-pos.project_analysis/v1",
  "analyzed_at": "2026-07-26T00:00:05.000Z",
  "stage_ref": {
    "stage": "REVIEW",
    "confidence_state": "CONFIRMED",
    "source": "project_stage.json",
    "detected_at": "2026-07-26T00:00:00.000Z"
  },
  "stage_explanation": "Проект на стадии проверки: материалы есть, итог ещё не принят.",
  "summary": "Краткая аналитическая сводка…",
  "risks": [],
  "opportunities": [],
  "soft_next_focus": "Имеет смысл пройти чек-лист приёмки по текущей задаче.",
  "blocking": false,
  "notes": "Эта сводка не назначает стадию и ничего не блокирует."
}
```

Правило именования:
- `next_step` в stage = логическое следствие стадии (Engine);  
- `soft_next_focus` в analysis = аналитическая рекомендация (Analyzer), может совпадать или быть шире, но **не перебивает** stage.next_step в UI первого экрана.

---

## 6. Границы ответственности (checklist)

| Действие | Stage Engine | project_analyzer |
|---|---|---|
| Выбрать `stage` | Да | Нет |
| Выставить `CONFIRMED` | Только по правилам Engine | Нет |
| Писать `project_stage.json` | Да | Нет |
| Писать `project_analysis.json` | Нет | Да |
| Объяснить стадию словами | Может дать evidence text | Да, основная UX-сводка |
| Риски / эвристики | Нет (это Health/Analyzer) | Да |
| Блокировать Gate/Accept | Нет | Нет |
| Использовать GitHub evidence | Да (через адаптер Engine) | Может упоминать в рисках, не меняя stage |

---

## 7. Что не делать при будущей реализации

1. Не удалять `project_analyzer.py` «потому что появился Stage Engine».  
2. Не давать analyzer параметр `force_stage` / запись в stage file.  
3. Не сливать оба JSON в один «умный» отчёт с единым полем stage от ИИ.  
4. Не начинать полную реализацию обоих компонентов в одном шаге без отдельных задач и scope.

---

## 8. Минимальный следующий шаг реализации (только план, не старт)

Когда команда решит кодировать:

1. Контракты JSON Schema для `project_stage.json` и `project_analysis.json`.  
2. Каркас Stage Engine (pure rules, без UI).  
3. Адаптер чтения stage в `project_analyzer` + запись только analysis.  
4. Регрессионный тест: analyzer не меняет stage file.

**Сейчас реализация не начинается** — только архитектурная фиксация.

---

## 9. Открытые решения (узкие)

1. **TTL:** обязан ли analyzer всегда ждать свежий Engine-run или может читать stage не старше N минут?  
   - Рекомендация: читать pin/TTL; если stale — `stage_ref.pending` и не выдумывать stage.  

2. **Один процесс или два CLI?**  
   - Рекомендация: два вызываемых модуля / две команды; оркестратор вызывает Engine → Analyzer.  

3. **Где живёт orchestrator в MVP?**  
   - Рекомендация: тонкий `refresh_project_insight.py` или шаг bridge — вне analyzer и вне engine core.
